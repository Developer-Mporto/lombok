package com.matheus.porto.ConversancaoIdade;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConvercaoidadeApplicationTests {

	@Test
	void contextLoads() {
	}

}
