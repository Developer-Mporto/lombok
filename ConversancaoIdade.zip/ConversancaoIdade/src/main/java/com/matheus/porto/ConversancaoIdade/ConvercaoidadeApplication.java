package com.matheus.porto.ConversancaoIdade;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ConvercaoidadeApplication {

	public static void main(String[] args) {
		SpringApplication.run(ConvercaoidadeApplication.class, args);
	}

}
